public class GifData {
    private Images images;

    public GifData(Images images) {
        this.images = images;
    }

    public Images getImages() {
        return images;
    }

    public void setImages(Images images) {
        this.images = images;
    }
}
