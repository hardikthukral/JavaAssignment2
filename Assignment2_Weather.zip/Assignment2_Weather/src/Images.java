public class Images {
    private ImageInfo original;

    public Images(ImageInfo original) {
        this.original = original;
    }

    public ImageInfo getOriginal() {
        return original;
    }

    public void setOriginal(ImageInfo original) {
        this.original = original;
    }
}
