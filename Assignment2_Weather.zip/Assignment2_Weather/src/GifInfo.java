public class GifInfo {
    private GifData data;

    public GifInfo(GifData data) {
        this.data = data;
    }

    public GifData getData() {
        return data;
    }

    public void setData(GifData data) {
        this.data = data;
    }
}
